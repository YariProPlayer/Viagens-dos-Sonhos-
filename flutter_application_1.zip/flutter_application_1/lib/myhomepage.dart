// myhomepage.dart
import 'package:flutter/material.dart';
 
List<Map<String, String>> destinosGlobal = [];
 
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
 
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}
 
class _MyHomePageState extends State<MyHomePage> {
 
  // método la para excluir
  void _deletarDestino(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Confirmar Exclusão"),
          content: Text("Deseja excluir ${destinosGlobal[index]['nomeLugar']}?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancelar"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() => destinosGlobal.removeAt(index));
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: Text("Excluir", style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }
 
  // Aqui é para editar as informações
  void _showEditDestino(BuildContext context, int index) {
    final nomeController = TextEditingController(text: destinosGlobal[index]['nomeLugar']);
    final paisController = TextEditingController(text: destinosGlobal[index]['pais']);
    final dataController = TextEditingController(text: destinosGlobal[index]['dataViagem']);
    final imagemController = TextEditingController(text: destinosGlobal[index]['urlImagem']);
 
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Editar Destino"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nomeController,
                  decoration: InputDecoration(labelText: "Nome do Lugar"),
                ),
                TextField(
                  controller: paisController,
                  decoration: InputDecoration(labelText: "País"),
                ),
                TextField(
                  controller: dataController,
                  decoration: InputDecoration(labelText: "Data da Viagem"),
                ),
                TextField(
                  controller: imagemController,
                  decoration: InputDecoration(labelText: "URL da Imagem"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancelar"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  destinosGlobal[index] = {
                    'urlImagem': imagemController.text,
                    'nomeLugar': nomeController.text,
                    'pais': paisController.text,
                    'dataViagem': dataController.text,
                  };
                });
                Navigator.pop(context);
              },
              child: Text("Salvar"),
            ),
          ],
        );
      },
    );
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Meus Destinos"),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: destinosGlobal.isEmpty
        ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.map, size: 60, color: Colors.grey),
                SizedBox(height: 20),
                Text("Nenhum destino cadastrado!"),
              ],
            ),
          )
        : ListView.builder(
            padding: EdgeInsets.all(8),
            itemCount: destinosGlobal.length,
            itemBuilder: (context, index) {
              return ListTile(
                leading: Image.network(
                  destinosGlobal[index]['urlImagem']!,
                  width: 50,
                  height: 50,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                    Icon(Icons.image, color: Colors.grey),
                ),
                title: Text(destinosGlobal[index]['nomeLugar']!),
                subtitle: Text("${destinosGlobal[index]['pais']!} - ${destinosGlobal[index]['dataViagem']!}"),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _showEditDestino(context, index),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deletarDestino(index),
                    ),
                  ],
                ),
              );
            },
          ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => TelaCadastro()),
          ).then((_) => setState(() {}));
        },
        backgroundColor: Colors.orange,
        child: Icon(Icons.add),
      ),
    );
  }
}
 
// Tela de Cadastro
class TelaCadastro extends StatefulWidget {
  @override
  _TelaCadastroState createState() => _TelaCadastroState();
}
 
class _TelaCadastroState extends State<TelaCadastro> {
  final nomeController = TextEditingController();
  final paisController = TextEditingController();
  final dataController = TextEditingController();
  final imagemController = TextEditingController();
 
  void _adicionarDestino() {
    if (nomeController.text.isNotEmpty &&
        paisController.text.isNotEmpty &&
        dataController.text.isNotEmpty &&
        imagemController.text.isNotEmpty) {
     
      destinosGlobal.add({
        'urlImagem': imagemController.text,
        'nomeLugar': nomeController.text,
        'pais': paisController.text,
        'dataViagem': dataController.text,
      });
     
      Navigator.pop(context);
    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cadastrar Destino"),
        backgroundColor: Colors.orange,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: nomeController,
              decoration: InputDecoration(labelText: "Nome do Lugar"),
            ),
            TextField(
              controller: paisController,
              decoration: InputDecoration(labelText: "País"),
            ),
            TextField(
              controller: dataController,
              decoration: InputDecoration(labelText: "Data da Viagem"),
            ),
            TextField(
              controller: imagemController,
              decoration: InputDecoration(labelText: "URL da Imagem"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _adicionarDestino,
              child: Text("Salvar Destino"),
            ),
          ],
        ),
      ),
    );
  }
}