// myhomepage.dart
import 'package:flutter/material.dart';

// Lista global para compartilhar entre as telas
List<Map<String, String>> destinosGlobal = [];

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  
  //Metodo Excluir
  void _deletarDestino(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 28),
              SizedBox(width: 10),
              Text("Confirmar Exclusão"),
            ],
          ),
          content: Text("Deseja realmente excluir o destino ${destinosGlobal[index]['nomeLugar']}?"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Cancelar", style: TextStyle(color: Colors.grey[600])),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  destinosGlobal.removeAt(index);
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text("Excluir", style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  //MODAL PARA EDITAR DESTINOS
  void _showEditDestino(BuildContext context, int index) {
    final TextEditingController nomeLugarController = TextEditingController(
      text: destinosGlobal[index]['nomeLugar'],
    );
    final TextEditingController paisController = TextEditingController(
      text: destinosGlobal[index]['pais'],
    );
    final TextEditingController dataViagemController = TextEditingController(
      text: destinosGlobal[index]['dataViagem'],
    );
    final TextEditingController urlImagemController = TextEditingController(
      text: destinosGlobal[index]['urlImagem'],
    );

    //Criando Variavel para erro
    String? messagemErro;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.blue[300],
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      padding: EdgeInsets.all(16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.edit_location, color: Colors.white, size: 24),
                              SizedBox(width: 8),
                              Text(
                                "Editar Destino",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: Icon(Icons.close, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        children: [
                          TextField(
                            controller: nomeLugarController,
                            decoration: InputDecoration(
                              labelText: "Nome do Lugar",
                              prefixIcon: Icon(Icons.location_on, color: Colors.blue[400]),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide(color: Colors.blue[400]!, width: 2),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          TextField(
                            controller: paisController,
                            decoration: InputDecoration(
                              labelText: "País",
                              prefixIcon: Icon(Icons.flag, color: Colors.green[400]),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide(color: Colors.green[400]!, width: 2),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          TextField(
                            controller: dataViagemController,
                            decoration: InputDecoration(
                              labelText: "Data da Viagem",
                              prefixIcon: Icon(Icons.calendar_today, color: Colors.orange[400]),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide(color: Colors.orange[400]!, width: 2),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          TextField(
                            controller: urlImagemController,
                            decoration: InputDecoration(
                              labelText: 'URL da imagem do destino',
                              prefixIcon: Icon(Icons.image, color: Colors.purple[400]),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide(color: Colors.purple[400]!, width: 2),
                              ),
                            ),
                          ),
                          SizedBox(height: 20),
                          if (messagemErro != null)
                            Container(
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.red[50],
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Colors.red[300]!),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.error, color: Colors.red),
                                  SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      messagemErro!,
                                      style: TextStyle(
                                        color: Colors.red[700],
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              ElevatedButton.icon(
                                onPressed: () {
                                  //ação botão
                                  if (nomeLugarController.text.trim().isEmpty ||
                                      paisController.text.trim().isEmpty ||
                                      dataViagemController.text.trim().isEmpty ||
                                      urlImagemController.text.trim().isEmpty) {
                                    setStateDialog(() {
                                      messagemErro = "Preencha todos os campos obrigatórios";
                                    });
                                  } else {
                                    setState(() {
                                      destinosGlobal[index] = {
                                        'urlImagem': urlImagemController.text,
                                        'nomeLugar': nomeLugarController.text,
                                        'pais': paisController.text,
                                        'dataViagem': dataViagemController.text,
                                      };
                                    });
                                    Navigator.of(context).pop();
                                  }
                                },
                                icon: Icon(Icons.save, color: Colors.white),
                                label: Text('Salvar', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green[500],
                                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                              ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                icon: Icon(Icons.cancel, color: Colors.white),
                                label: Text('Cancelar', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.grey[500],
                                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.flight_takeoff, color: Colors.white, size: 28),
            SizedBox(width: 8),
            Text("Meus Destinos", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.blue[400],
        elevation: 0,
      ),
      body: destinosGlobal.isEmpty 
        ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.map_outlined, size: 80, color: Colors.grey[400]),
                SizedBox(height: 20),
                Text(
                  "Nenhum destino cadastrado ainda!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "Clique no + para adicionar seu primeiro destino dos sonhos!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          )
        : ListView.builder(
            padding: EdgeInsets.all(8),
            itemCount: destinosGlobal.length,
            itemBuilder: (context, index) {
              return DestinoCard(
                destinosGlobal[index]['urlImagem']!,
                destinosGlobal[index]['nomeLugar']!,
                destinosGlobal[index]['pais']!,
                destinosGlobal[index]['dataViagem']!,
                () => _showEditDestino(context, index),
                () => _deletarDestino(index),
              );
            },
          ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
        ),
        child: FloatingActionButton(
          onPressed: () {
            // Navega para tela de cadastro
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TelaCadastro()),
            ).then((_) {
              // Atualiza a tela quando voltar do cadastro
              setState(() {});
            });
          },
          backgroundColor: Colors.orange[400],
          child: Icon(Icons.add_location_alt, color: Colors.white, size: 28),
        ),
      ),
    );
  }
}

// NOVA TELA DE CADASTRO
class TelaCadastro extends StatefulWidget {
  @override
  _TelaCadastroState createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final TextEditingController nomeLugarController = TextEditingController();
  final TextEditingController paisController = TextEditingController();
  final TextEditingController dataViagemController = TextEditingController();
  final TextEditingController urlImagemController = TextEditingController();
  String? messagemErro;

  void _adicionarDestino() {
    if (nomeLugarController.text.trim().isEmpty ||
        paisController.text.trim().isEmpty ||
        dataViagemController.text.trim().isEmpty ||
        urlImagemController.text.trim().isEmpty) {
      setState(() {
        messagemErro = "Preencha todos os campos obrigatórios";
      });
    } else {
      // Modal de confirmação de cadastro
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 28),
                SizedBox(width: 10),
                Text("Confirmar Cadastro"),
              ],
            ),
            content: Text("Deseja realmente cadastrar este destino?"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("Cancelar", style: TextStyle(color: Colors.grey[600])),
              ),
              ElevatedButton(
                onPressed: () {
                  destinosGlobal.add({
                    'urlImagem': urlImagemController.text,
                    'nomeLugar': nomeLugarController.text,
                    'pais': paisController.text,
                    'dataViagem': dataViagemController.text,
                  });
                  Navigator.of(context).pop(); // Fecha o dialog
                  Navigator.of(context).pop(); // Volta para tela anterior
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text("Cadastrar", style: TextStyle(color: Colors.white)),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.add_location, color: Colors.white, size: 24),
            SizedBox(width: 8),
            Text("Cadastrar Destino", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.orange[400],
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  TextField(
                    controller: nomeLugarController,
                    decoration: InputDecoration(
                      labelText: "Nome do Lugar",
                      prefixIcon: Icon(Icons.location_on, color: Colors.blue[400]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.blue[400]!, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: paisController,
                    decoration: InputDecoration(
                      labelText: "País",
                      prefixIcon: Icon(Icons.flag, color: Colors.green[400]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.green[400]!, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: dataViagemController,
                    decoration: InputDecoration(
                      labelText: "Data da Viagem",
                      prefixIcon: Icon(Icons.calendar_today, color: Colors.orange[400]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.orange[400]!, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: urlImagemController,
                    decoration: InputDecoration(
                      labelText: "URL da imagem do destino",
                      prefixIcon: Icon(Icons.image, color: Colors.purple[400]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.purple[400]!, width: 2),
                      ),
                      filled: true,
                      fillColor: Colors.grey[50],
                    ),
                  ),
                  SizedBox(height: 25),
                  if (messagemErro != null)
                    Container(
                      margin: EdgeInsets.only(bottom: 20),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red[50],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red[300]!),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.error, color: Colors.red),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              messagemErro!,
                              style: TextStyle(
                                color: Colors.red[700],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      ElevatedButton.icon(
                        onPressed: _adicionarDestino,
                        icon: Icon(Icons.save, color: Colors.white),
                        label: Text('Salvar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[500],
                          padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          elevation: 3,
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icon(Icons.cancel, color: Colors.white),
                        label: Text('Cancelar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[500],
                          padding: EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          elevation: 3,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DestinoCard extends StatelessWidget {
  final String urlImagem;
  final String nomeLugar;
  final String pais;
  final String dataViagem;
  final VoidCallback onEdit;
  final VoidCallback onDeletar;

  const DestinoCard(
    this.urlImagem,
    this.nomeLugar,
    this.pais,
    this.dataViagem,
    this.onEdit,
    this.onDeletar, {
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          color: Colors.white,
          child: Column(
            children: [
              // Parte superior colorida
              Container(
                height: 8,
                color: Colors.blue[400],
              ),
              // Conteúdo principal
              Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    // Imagem do destino
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            blurRadius: 5,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Image.network(
                          urlImagem, 
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.grey[200],
                              child: Icon(
                                Icons.image_not_supported,
                                color: Colors.grey[400],
                                size: 40,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    // Informações do destino
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.location_on, color: Colors.blue[500], size: 18),
                              SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  nomeLugar,
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[800],
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.flag, color: Colors.green[500], size: 16),
                              SizedBox(width: 4),
                              Text(
                                pais,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[600],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.calendar_today, color: Colors.orange[500], size: 16),
                              SizedBox(width: 4),
                              Text(
                                dataViagem,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // Botões de ação
                    Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.blue.withOpacity(0.2),
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            onPressed: onEdit,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[500],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              padding: EdgeInsets.all(12),
                              minimumSize: Size(45, 45),
                            ),
                            child: Icon(Icons.edit, color: Colors.white, size: 18),
                          ),
                        ),
                        SizedBox(height: 8),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.withOpacity(0.2),
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            onPressed: onDeletar,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red[500],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              padding: EdgeInsets.all(12),
                              minimumSize: Size(45, 45),
                            ),
                            child: Icon(Icons.delete, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}